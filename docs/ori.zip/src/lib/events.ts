
import eventsData from '@/../public/data/events.json';
import type { Event } from './types';

// This is a placeholder for a real data fetching function.
// In a real application, this would fetch data from a database like Firestore.

const allEvents: Event[] = eventsData as Event[];

/**
 * Simulates fetching all events from a database.
 * @returns A promise that resolves to an array of events.
 */
export async function getEvents(): Promise<Event[]> {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));
  return allEvents;
}

/**
 * Simulates fetching a single event by its slug.
 * @param slug The slug of the event to fetch.
 * @returns A promise that resolves to the event, or null if not found.
 */
export async function getEventBySlug(slug: string): Promise<Event | null> {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 300));
  const event = allEvents.find((e) => e.slug === slug);
  return event || null;
}

/**
 * Simulates fetching a single event by its ID.
 * @param id The ID of the event to fetch.
 * @returns A promise that resolves to the event, or null if not found.
 */
export async function getEventById(id: string): Promise<Event | null> {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 300));
    const event = allEvents.find((e) => e.id === id);
    return event || null;
}
