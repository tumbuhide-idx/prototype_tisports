# **App Name**: TIC Sport UI Prototype

## Core Features:

- Landing Page with Event Grid: Display a landing page with a hero section, dummy search, and a grid of EventCard components fetched from static JSON.
- Event Detail Page: Show a detail page for an event, including a hero section, capacity bar, anonymized participant list, and a booking CTA that is active or disabled based on the event status in the mock data.
- Booking Sheet: Implement a booking sheet with non-functional input fields and a sticky summary bar with a CTA that navigates to the payment route without saving any data.
- Payment Panel: Design a payment panel displaying payment method options, a static amount, a static countdown label, and a dialog for uploading proof of payment (visual-only).
- Status Page: Render status pages for REVIEW, PAID, REJECTED, and EXPIRED states. PAID status should display a QR code placeholder and a payload text sample.
- Admin Preview: Create an admin preview page showcasing style guide elements, including color tokens, typography scales, buttons, cards, and form fields.

## Style Guidelines:

- Primary color: #5B2EFF - A vibrant purple for a sporty and modern feel.
- Secondary color: #FFD54F - A bright yellow as a secondary accent to complement the primary purple.
- Accent color: #7ADFFF - A light blue as an additional accent to add a fresh, energetic touch.
- Background color (Surface): #FFFFFF - Clean white background for a light theme.
- Muted color: #F3F4F6 - Light gray for muted backgrounds and subtle UI elements.
- Headings font: 'Poppins', a geometric sans-serif for headings.
- Body font: 'Inter', a grotesque-style sans-serif for body text.
- Use clear and recognizable icons to enhance usability. Ensure icons have appropriate aria-labels for accessibility.
- Mobile-first, responsive layout. Use an 8px spacing scale throughout the app. Employ a 1-column grid on mobile and a 2-3 column grid on desktop.
- Use subtle animations for transitions and interactions to enhance user experience without being distracting.